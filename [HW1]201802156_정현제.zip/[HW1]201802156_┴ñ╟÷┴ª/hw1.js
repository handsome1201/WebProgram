var diary_btn = document.getElementById("add");
diary_btn.addEventListener('click', opencontainer);

function opencontainer() {
    // Find the newDiv element by its ID
    var newDiv = document.getElementById("newDiv");

    // Check if newDiv is currently hidden (display: none)
    if (newDiv.style.display === "none" || newDiv.style.display === "") {
        // If hidden, show the newDiv
        newDiv.style.display = "block";
    } else {
        location.reload();
        newDiv.style.display = "none";
    }
}
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
document.addEventListener("DOMContentLoaded", function() {
    // Find all elements with the 'colored' class (assuming 'colored' class is on td elements)
    var coloredTds = document.querySelectorAll('.colored');

    // Add click event listener to each colored td element, calling openmodal function
    for (var i = 0; i < coloredTds.length; i++) {
        coloredTds[i].addEventListener('click', openmodal);
    }
});

function openmodal() {
    var modal = document.getElementById('modal');

    modal.style.display = 'block';
}
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
var cancel_btn = document.getElementById("cancel");
cancel_btn.addEventListener('click', closeModal);

function closeModal() {
    var firstmodal = document.getElementById("modal");
    // 모달을 숨깁니다 (display 속성을 'none'으로 설정).
    firstmodal.style.display = "none";
    modalOpen = false;
}
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
var save_btn = document.getElementById("save");
save_btn.addEventListener('click', saveData);

var todoList = [];
var talkList = [];
var ideaList = [];
var shoppingList = [];

var modalOpen = false;


function info(divid) {
    return divid;
}

function saveData() {
    var modal = document.getElementById("modal");

    var firstdiv1Text = document.getElementById("plan").value;
    var firstdiv2Text = document.getElementById("explain").value;
    var firstcategory = document.getElementById("select").value;

    if (firstdiv1Text.trim() === "" || firstdiv2Text.trim() === "") {
        alert("입력칸을 모두 채워주세요.");
        return;
    }
    alert("계획이 추가되었습니다.");
    var divid = addToTableCell(firstdiv1Text, firstdiv2Text, firstcategory)

    if (firstcategory === "todo") {
        todoList.push(info(divid));
    } else if (firstcategory === "talk") {
        talkList.push(info(divid));
    } else if (firstcategory === "idea") {
        ideaList.push(info(divid));
    } else if (firstcategory === "shopping") {
        shoppingList.push(info(divid));
    }
    // 모달을 닫습니다.
    closeModal();

}
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
function addToTableCell(firstdiv1Text, firstdiv2Text, firstcategory) {

    var cellId = clickedTdId;

    var createcell = document.getElementById(cellId);
    var cell = document.getElementById(cellId);
    var adddivtodo = document.createElement("div");
    var adddivtalk = document.createElement("div");
    var adddividea = document.createElement("div");
    var adddivshopping = document.createElement("div");
    var divId = null;

    if (firstcategory === "todo") {
        divId = Date.now(); // 현재 시간을 기반으로 고유한 id 생성
        adddivtodo.setAttribute("id", divId);
        adddivtodo.setAttribute("data-div1Text", firstdiv1Text);
        adddivtodo.setAttribute("data-div2Text", firstdiv2Text);
        adddivtodo.setAttribute("data-category", firstcategory);
        createcell.appendChild(adddivtodo);
        adddivtodo.textContent = firstdiv1Text;
        adddivtodo.classList.add("todo-bg");
    }
    else if(firstcategory === "talk") {
        divId = Date.now(); // 현재 시간을 기반으로 고유한 id 생성
        adddivtalk.setAttribute("id", divId);
        adddivtalk.setAttribute("data-div1Text", firstdiv1Text);
        adddivtalk.setAttribute("data-div2Text", firstdiv2Text);
        adddivtalk.setAttribute("data-category", firstcategory);
        createcell.appendChild(adddivtalk);
        adddivtalk.textContent = firstdiv1Text;
        adddivtalk.classList.add("talk-bg");
    }
    else if(firstcategory === "idea") {
        divId = Date.now(); // 현재 시간을 기반으로 고유한 id 생성
        adddividea.setAttribute("id", divId);
        adddividea.setAttribute("data-div1Text", firstdiv1Text);
        adddividea.setAttribute("data-div2Text", firstdiv2Text);
        adddividea.setAttribute("data-category", firstcategory);
        createcell.appendChild(adddividea);
        adddividea.textContent = firstdiv1Text;
        adddividea.classList.add("idea-bg");
    }
    else if(firstcategory === "shopping"){
        divId = Date.now(); // 현재 시간을 기반으로 고유한 id 생성
        adddivshopping.setAttribute("id", divId);
        adddivshopping.setAttribute("data-div1Text", firstdiv1Text);
        adddivshopping.setAttribute("data-div2Text", firstdiv2Text);
        adddivshopping.setAttribute("data-category", firstcategory);
        createcell.appendChild(adddivshopping);
        adddivshopping.textContent = firstdiv1Text;
        adddivshopping.classList.add("shopping-bg");
    }


    var table2Div = document.getElementById('table2');
    var newDiv = document.createElement('div');
    newDiv.id = 'new' + divId;

    if (firstcategory === "todo") {
        newDiv.setAttribute("data-div1Text", firstdiv1Text);
        newDiv.setAttribute("data-category", firstcategory);
        table2Div.appendChild(newDiv);
        newDiv.textContent = firstdiv1Text;
        newDiv.classList.add("new-todo-bg");
        todoList.push(info(newDiv.id));
    }
    else if(firstcategory === "talk") {
        newDiv.setAttribute("data-div1Text", firstdiv1Text);
        newDiv.setAttribute("data-category", firstcategory);
        table2Div.appendChild(newDiv);
        newDiv.textContent = firstdiv1Text;
        newDiv.classList.add("new-talk-bg");
        talkList.push(info(newDiv.id));
    }
    else if(firstcategory === "idea") {
        newDiv.setAttribute("data-div1Text", firstdiv1Text);
        newDiv.setAttribute("data-category", firstcategory);
        table2Div.appendChild(newDiv);
        newDiv.textContent = firstdiv1Text;
        newDiv.classList.add("new-idea-bg");
        ideaList.push(info(newDiv.id));
    }
    else if(firstcategory === "shopping") {
        newDiv.setAttribute("data-div1Text", firstdiv1Text);
        newDiv.setAttribute("data-category", firstcategory);
        table2Div.appendChild(newDiv);
        newDiv.textContent = firstdiv1Text;
        newDiv.classList.add("new-shopping-bg");
        shoppingList.push(info(newDiv.id));
    }

    return divId;
}
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
var clickedTdId = ''; // 클릭된 td 요소의 ID를 저장할 변수

function handleTdClick(event) {
    clickedTdId = event.target.id;
    var clickedDiv = document.getElementById(clickedTdId);
    if (event.target.tagName === 'DIV' && clickedDiv) {
        var firstdiv1Text = clickedDiv.getAttribute('data-div1Text');
        var firstdiv2Text = clickedDiv.getAttribute('data-div2Text');
        var firstcategory = clickedDiv.getAttribute('data-category');


        // 모달 열기 함수 호출
        showsecondModal(firstdiv1Text, firstdiv2Text, firstcategory);


    } else {
        // 셀의 다른 부분을 클릭한 경우
        showModal('', '', '');
    }
}

// Get all td elements inside the table row with class "colored"
var tds = document.querySelectorAll('.colored td');

// Add click event listener to each td element
tds.forEach(function(td) {
    td.addEventListener('click', function(event) {
        event.stopPropagation(); // 이벤트 전파 방지

        // 현재 모달이 열려 있지 않을 때만 실행
        if (!modalOpen) {
            handleTdClick(event);
        }
    });
});
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ


function showModal(firstdiv1Text, firstdiv2Text, firstcategory) {
    var modal = document.getElementById("modal");
    modal.style.display = "block";

    var firstplan = document.getElementById("plan");
    var firstexplain = document.getElementById("explain");
    var firstselect = document.getElementById("select");

    firstplan.value = firstdiv1Text || "";
    firstexplain.value = firstdiv2Text || "";
    firstselect.value = firstcategory || "todo";


    addToTableCell(firstdiv1Text, firstdiv2Text, firstcategory)
    modalOpen = true;
}
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
function showsecondModal(firstdiv1Text, firstdiv2Text, firstcategory) {
    var modalcheck = document.getElementById("modal_check");
    modalcheck.style.display = "block";

    var seconddiv1Text = document.getElementById("plan1");
    var seconddiv2Text = document.getElementById("explain1");
    var secondcategory = document.getElementById("select1");

    seconddiv1Text.value = firstdiv1Text;
    seconddiv2Text.value = firstdiv2Text;
    secondcategory.value = firstcategory;

    modalOpen = true;

}
//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
var close_Icon = document.getElementById("mode_close");
close_Icon.addEventListener("click", closesecondModal);

function closesecondModal() {
    var secondModal = document.getElementById("modal_check");
    secondModal.style.display = "none";
    modalOpen = false; // 모달이 닫혔음을 표시
}

//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
var delete_Icon = document.getElementById("mode_delete");
delete_Icon.addEventListener("click", deleteModal);

function deleteModal() {
    var divToRemove = document.getElementById(clickedTdId);
    var rightdivToRemove = document.getElementById('new' + clickedTdId);

    if (divToRemove && rightdivToRemove) {
        divToRemove.parentNode.removeChild(divToRemove);
        rightdivToRemove.parentNode.removeChild(rightdivToRemove);
        alert("삭제되었습니다.");
        closesecondModal();
    }

    for(let i = 0; i < todoList.length; i++) {
      if(todoList[i] == clickedTdId)  {
        todoList.splice(i, 1);
        i--;
      }
    }

    talkList = talkList.filter(function(item) {
        return item.id != divToRemove;
    });
    ideaList = ideaList.filter(function(item) {
        return item.id != divToRemove;
    });
    shoppingList = shoppingList.filter(function(item) {
        return item.id != divToRemove;
    });
}

//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
var edit_Icon = document.getElementById("mode_edit");
edit_Icon.addEventListener("click", editModal);

function editModal() {
    document.getElementById("plan1").readOnly = false;
    document.getElementById("explain1").readOnly = false;
    document.getElementById("select1").disabled = false;

    var saveButtonExists = document.getElementById("saveButton") !== null;
    var cancelButtonExists = document.getElementById("cancelButton") !== null;

    if (!saveButtonExists) {
        var savebutton = document.createElement("button");
        savebutton.textContent = "저장";
        savebutton.setAttribute("id", "saveButton");

        savebutton.addEventListener("click", function() {
            var newDiv1Text = document.getElementById("plan1").value;
            var newDiv2Text = document.getElementById("explain1").value;
            var newCategory = document.getElementById("select1").value;

            // 기존 div의 ID를 사용하여 해당 div를 가져옵니다.
            var existingDiv = document.getElementById(clickedTdId);
            var secondExistingDiv = document.getElementById("new" + clickedTdId);

            // 기존 div의 데이터 속성을 업데이트합니다.
            existingDiv.setAttribute("data-div1Text", newDiv1Text);
            existingDiv.setAttribute("data-div2Text", newDiv2Text);
            existingDiv.setAttribute("data-category", newCategory);

            // 새로운 카테고리에 해당하는 클래스를 추가합니다.
            existingDiv.classList.remove("todo-bg", "talk-bg", "idea-bg", "shopping-bg");
            secondExistingDiv.classList.remove("new-todo-bg", "new-talk-bg", "new-idea-bg", "new-shopping-bg");

            if (newCategory === "todo") {
                existingDiv.classList.add("todo-bg");
                secondExistingDiv.classList.add("new-todo-bg");
            } else if (newCategory === "talk") {
                existingDiv.classList.add("talk-bg");
                secondExistingDiv.classList.add("new-talk-bg");
            } else if (newCategory === "idea") {
                existingDiv.classList.add("idea-bg");
                secondExistingDiv.classList.add("new-idea-bg");
            } else if (newCategory === "shopping") {
                existingDiv.classList.add("shopping-bg");
                secondExistingDiv.classList.add("new-shopping-bg");
            }

            // 기존 div의 텍스트 내용을 업데이트합니다.
            existingDiv.textContent = newDiv1Text;
            secondExistingDiv.textContent = newDiv1Text;

            // 저장 버튼과 취소 버튼을 제거합니다.
            var saveButton = document.getElementById("saveButton");
            var cancelButton = document.getElementById("cancelButton");
            if (saveButton) {
                saveButton.parentNode.removeChild(saveButton);
            }
            if (cancelButton) {
                cancelButton.parentNode.removeChild(cancelButton);
                document.getElementById("plan1").readOnly = true;
                document.getElementById("explain1").readOnly = true;
                document.getElementById("select1").disabled = true;
            }

            // 모달을 닫습니다.
            closesecondModal();
        });

        var parentElement = document.getElementById("modal_check");
        parentElement.appendChild(savebutton);
    }

    if (!cancelButtonExists) {
        var cancelbutton = document.createElement("button");
        cancelbutton.textContent = "취소";
        cancelbutton.setAttribute("id", "cancelButton");

        cancelbutton.addEventListener("click", function() {
            var saveButton = document.getElementById("saveButton");
            var cancelButton = document.getElementById("cancelButton");

            if (saveButton) {
                saveButton.parentNode.removeChild(saveButton);
            }
            if (cancelButton) {
                cancelButton.parentNode.removeChild(cancelButton);
            }

            // 모달을 닫습니다.
            closesecondModal();
        });

        var parentElement = document.getElementById("modal_check");
        parentElement.appendChild(cancelbutton);
    }
}

//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
// 체크박스 요소 가져오기
var todo_check = document.getElementById("todocheck");
var talk_check = document.getElementById("talkcheck");
var idea_check = document.getElementById("ideacheck");
var shopping_check = document.getElementById("shoppingcheck");

// 각 체크박스에 이벤트 리스너 추가
todo_check.addEventListener("change", filterDivs);
talk_check.addEventListener("change", filterDivs);
idea_check.addEventListener("change", filterDivs);
shopping_check.addEventListener("change", filterDivs);

function findUniqElem(arr1, arr2) {
  return arr1.concat(arr2)
    	 .filter(item => !arr1.includes(item) || !arr2.includes(item));
}

function filterDivs() {
    // 체크된 항목에 대한 ID를 저장할 배열 생성
    var visibleDivs = [];
    var noshowvisibleDivs = [];
    var showvisibleDivs = [];

    visibleDivs = visibleDivs.concat(todoList);
    visibleDivs = visibleDivs.concat(talkList);
    visibleDivs = visibleDivs.concat(ideaList);
    visibleDivs = visibleDivs.concat(shoppingList);

    // 각 체크박스의 상태를 확인하여 visibleDivs 배열에 해당하는 ID 추가
    if (todo_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(todoList);
        findUniqElem(showvisibleDivs, visibleDivs);
        noshowvisibleDivs = noshowvisibleDivs.concat(visibleDivs);
        showvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'block';
            }
        });
        noshowvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'none';
            }
        });
        noshowvisibleDivs = []
    }
    if (talk_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(talkList);
        findUniqElem(showvisibleDivs, visibleDivs);
        noshowvisibleDivs = noshowvisibleDivs.concat(visibleDivs);
        showvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'block';
            }
        });
        noshowvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'none';
            }
        });
        noshowvisibleDivs = []
    }
    if (idea_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(ideaList);
        findUniqElem(showvisibleDivs, visibleDivs);
        noshowvisibleDivs = noshowvisibleDivs.concat(visibleDivs);
        showvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'block';
            }
        });
        noshowvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'none';
            }
        });
        noshowvisibleDivs = []

    }
    if (shopping_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(shoppingList);
        findUniqElem(showvisibleDivs, visibleDivs);
        noshowvisibleDivs = noshowvisibleDivs.concat(visibleDivs);
        showvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'block';
            }
        });
        noshowvisibleDivs.forEach(function(divId) {
            var div = document.getElementById(divId);
            if (div) {
                div.style.display = 'none';
            }
        });
        noshowvisibleDivs = []
    }
    //ㅡㅡㅡㅡㅡ체크표 없앨때
    if (!todo_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(noshowvisibleDivs);

    }
    if (!talk_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(noshowvisibleDivs);

    }
    if (!idea_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(noshowvisibleDivs);

    }
    if (!shopping_check.checked) {
        showvisibleDivs = showvisibleDivs.concat(noshowvisibleDivs);
    }
    if(!todo_check.checked && !talk_check.checked && !idea_check.checked && !shopping_check.checked){
        showvisibleDivs = showvisibleDivs.concat(visibleDivs);
    }


    showvisibleDivs.forEach(function(divId) {
        var div = document.getElementById(divId);
        if (div) {
            div.style.display = 'block';
        }
    });
    noshowvisibleDivs.forEach(function(divId) {
        var div = document.getElementById(divId);
        if (div) {
            div.style.display = 'none';
        }
    });

}

//ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
document.addEventListener('click', handleDivClick);

function removeFromArray(arr, value) {
    var index = arr.indexOf(value);
    if (index !== -1) {
        arr.splice(index, 1);
    }
}

// 클릭 이벤트 핸들러
function handleDivClick(event) {
    var clickedElement = event.target;

    // 클릭된 요소의 id가 "new"로 시작하는 경우 알림창 띄우기
    if (clickedElement.id && clickedElement.id.startsWith('new')) {
        // "new"를 제외한 순수한 id 가져오기
        var originalId = clickedElement.id.substring(3);

        // 삭제되었습니다. 알림창 띄우기
        alert('삭제되었습니다.');

        // 클릭된 div 요소 삭제하기 (부모 노드로부터 제거)
        clickedElement.parentNode.removeChild(clickedElement);

        // 같은 id를 가진 기존 div 요소 삭제하기
        var existingElement = document.getElementById(originalId);
        if (existingElement) {
            existingElement.parentNode.removeChild(existingElement);

            // 배열에서 해당 값을 제거
            removeFromArray(todoList, parseInt(originalId));
            removeFromArray(talkList, parseInt(originalId));
            removeFromArray(ideaList, parseInt(originalId));
            removeFromArray(shoppingList, parseInt(originalId));
        }
    }
}