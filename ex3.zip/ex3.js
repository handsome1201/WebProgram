document.getElementById("sub").addEventListener("click", subByClick);

function subByClick(){
    const todo = document.getElementById("todo").value;
    var li = document.createElement("li");
    var button = document.createElement("input");
    var innerlist = document.createElement("ol");
    button.type = "submit";
    button.value = "하위 할 일 추가";22
    innerlist.setAttribute("type","A");

    button.addEventListener("click", function(){ inputInnerList(innerlist) });

    var txt = document.createElement("span");
    txt.innerText = todo;
    txt.addEventListener("click", deleteByClick);
    li.appendChild(txt);
    li.appendChild(button);
    li.appendChild(innerlist);
    document.getElementById("list").appendChild(li);
}
function inputInnerList(ol){
    var input = prompt("상세정보 입력: ");
    if(input !== '' && input !== null){
        var txt = document.createTextNode(input);
        var li = document.createElement("li");
        li.appendChild(txt);
        ol.appendChild(li);
    }
}
function deleteByClick(event) {
    var clickedElement = event.target.parentNode;
    var ol = clickedElement.lastChild;
    while(ol.firstChild) {
        ol.firstChild.remove();
    }
}