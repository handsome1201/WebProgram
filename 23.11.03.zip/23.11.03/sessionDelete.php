<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ko">
<body>

<?php
$initialData = array(
    array("홍길동", 1),
    array("이순신", 2),
    array("이도훈", 3),
    array("장민호", 2),
    array("홍민호", 3)
);
if (!isset($_SESSION["student"])) {
    $_SESSION["student"] = $initialData;
}
var_dump($_SESSION["student"]);
echo "<br>";

$result = $_SESSION["student"];
$name = $_POST["name"];
$grade = $_POST["grade"];
$boundary_grade = $_POST["boundary_grade"];
$size = count($_SESSION["student"]);
$_SESSION["student"] = array();
for ($i = 0; $i < $size; $i++) {
    $stu = isset($result[$i]) ? $result[$i] : null;
    $getName = isset($result[$i][0]) ? $result[$i][0] : null;
    $getGrade = isset($result[$i][1]) ? $result[$i][1] : null;

    if ($getGrade >= $grade && $getGrade <= $boundary_grade) {
        if ($name != "" && strpos($getName, $name) !== false) {
            echo $getName . "을 삭제하였습니다.<br>";
        } elseif ($name == "") {
            echo $getName . "을 삭제하였습니다.<br>";
        } else {
            $arr = array($getName, $getGrade);
            array_push($_SESSION["student"], $arr);
        }
    } else {
        $arr = array($getName, $getGrade);
        array_push($_SESSION["student"], $arr);
    }
}

echo " \n";

var_dump($_SESSION["student"]);

?>
</body>
</html>
