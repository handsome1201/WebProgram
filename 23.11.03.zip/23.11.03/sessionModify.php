<?php
session_start();

$tmp = array();
array_push($tmp, array("홍길동", "1"));
array_push($tmp, array("이순신", "2"));
array_push($tmp, array("이도훈", "3"));
array_push($tmp, array("장민호", "2"));
array_push($tmp, array("홍민호", "3"));
$_SESSION['data'] = $tmp;

var_dump($_SESSION['data']);
echo "<br>";

$name = $_POST['name'];
$grade = $_POST['grade'];
$i = 0;
$arr = array();
while(isset($_SESSION['data'][$i])) {
    $getName = $_SESSION['data'][$i][0];
    $getGrade = $_SESSION['data'][$i][1];
    if($name != null) {
        if (strpos($getName, $name) !== false) {
            echo $getName . "의 학년을 " . $grade . "학년으로 변경하였습니다.<br>";
            array_push($arr, array($getName, $grade));
        } else {
            array_push($arr, array($getName, $getGrade));
        }
    }
    $i++;
}

$_SESSION['data'] = $arr;

var_dump($_SESSION['data']);
echo "<br>";

session_destroy();

?>