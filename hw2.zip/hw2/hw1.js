// HTML 문서가 로드될 때 실행되는 함수
document.addEventListener("DOMContentLoaded", function () {
    // 월 선택 select 요소를 가져옴
    var monthSelect = document.getElementById("month");

    // 각 월에 해당하는 div 요소들을 가져옴
    var janDiv = document.getElementById("jan");
    var febDiv = document.getElementById("feb");
    var marDiv = document.getElementById("mar");
    var aprDiv = document.getElementById("apr");
    var mayDiv = document.getElementById("may");
    var juneDiv = document.getElementById("june");
    var julyDiv = document.getElementById("july");
    var augDiv = document.getElementById("aug");
    var sepDiv = document.getElementById("sep");
    var octDiv = document.getElementById("oct");
    var noDiv = document.getElementById("no");
    var decDiv = document.getElementById("dec");

    // 월 선택 select 요소가 변경될 때 실행되는 함수
    monthSelect.addEventListener("change", function () {
        // 선택된 월의 값 가져오기
        var selectedMonth = monthSelect.value;

        // 모든 월에 해당하는 div를 숨김
        janDiv.style.display = "none";
        febDiv.style.display = "none";
        marDiv.style.display = "none";
        aprDiv.style.display = "none";
        mayDiv.style.display = "none";
        juneDiv.style.display = "none";
        julyDiv.style.display = "none";
        augDiv.style.display = "none";
        sepDiv.style.display = "none";
        octDiv.style.display = "none";
        noDiv.style.display = "none";
        decDiv.style.display = "none";

        // 선택된 월에 해당하는 div를 표시
        if (selectedMonth === "1") {
            janDiv.style.display = "block";
        } else if (selectedMonth === "2") {
            febDiv.style.display = "block";
        } else if (selectedMonth === "3") {
            marDiv.style.display = "block";
        }else if (selectedMonth === "4") {
            aprDiv.style.display = "block";
        }else if (selectedMonth === "5") {
            mayDiv.style.display = "block";
        }else if (selectedMonth === "6") {
            juneDiv.style.display = "block";
        }else if (selectedMonth === "7") {
            julyDiv.style.display = "block";
        }else if (selectedMonth === "8") {
            augDiv.style.display = "block";
        }else if (selectedMonth === "9") {
            sepDiv.style.display = "block";
        }else if (selectedMonth === "10") {
            octDiv.style.display = "block";
        }else if (selectedMonth === "11") {
            noDiv.style.display = "block";
        }else if (selectedMonth === "12") {
            decDiv.style.display = "block";
        }

        // 선택된 월에 대한 추가적인 처리를 원한다면 여기에 코드를 추가할 수 있습니다.
    });
});
