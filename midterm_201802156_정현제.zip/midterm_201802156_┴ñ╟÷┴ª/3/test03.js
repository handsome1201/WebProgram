document.addEventListener("DOMContentLoaded", function() {
    var form = document.querySelector("form");

    form.addEventListener("submit", function(event) {
        // 이름 입력 값 확인
        var nameInput = document.getElementById("name");
        if (!nameInput.value) {
            alert("이름에 문자를 입력해 주세요.");
            event.preventDefault(); // 폼 제출을 막음
            return;
        }

        // 등급 선택 확인
        var selectedGrade = document.querySelector("input[name='select']:checked");
        if (!selectedGrade) {
            alert("고객의 등급을 선택해 주세요.");
            event.preventDefault(); // 폼 제출을 막음
            return;
        }

        // 주문 날짜 입력 값 확인
        var monthInput = document.querySelector("input[name='month']");
        var dayInput = document.querySelector("input[name='day']");
        var monthValue = parseInt(monthInput.value);
        var dayValue = parseInt(dayInput.value);

        // 날짜 유효성 검사
        if (isNaN(monthValue) || isNaN(dayValue) || monthValue <= 0 || dayValue <= 0) {
            alert("날짜에 숫자를 입력해 주세요.");
            event.preventDefault(); // 폼 제출을 막음
            return;
        }

        // 날짜 유효성 검사
        var isValidDate = isValidDateInput(monthValue, dayValue, 2023);
        if (!isValidDate) {
            alert("유효한 날짜를 입력해 주세요.");
            event.preventDefault(); // 폼 제출을 막음
            return;
        }

        // 제품 수량 확인
        var milkCheckbox = document.querySelector("input[name='milkcheck']");
        var mandooCheckbox = document.querySelector("input[name='mandoocheck']");
        var noshimCheckbox = document.querySelector("input[name='noshimocheck']");
        var milkQuantity = parseInt(document.getElementById("milk").value);
        var mandooQuantity = parseInt(document.getElementById("mandoo").value);
        var noshimQuantity = parseInt(document.getElementById("noshim").value);

        var hasSelectedProduct = milkQuantity > 0 || mandooQuantity > 0 || noshimQuantity > 0;
        var hasZeroQuantity = (milkQuantity === 0 && document.querySelector("input[name='milkcheck']").checked) ||
            (mandooQuantity === 0 && document.querySelector("input[name='mandoocheck']").checked) ||
            (noshimQuantity === 0 && document.querySelector("input[name='noshimocheck']").checked);

        var hasExceededQuantity = milkQuantity > 10 || mandooQuantity > 10 || noshimQuantity > 10;

        var hasSelectedProduct = milkCheckbox.checked || mandooCheckbox.checked || noshimCheckbox.checked;

        if (!hasSelectedProduct) {
            event.preventDefault();
            alert("최소 한 개의 제품을 선택하셔야 합니다.");
            event.preventDefault();
            return;
        }
        else if (hasZeroQuantity && hasExceededQuantity) {
                    event.preventDefault();
                    alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
                    document.getElementById("milk").value = 1;
                    document.getElementById("mandoo").value = 1;
                    document.getElementById("noshim").value = 1;
                } else if (hasZeroQuantity) {
                    event.preventDefault();
                    alert("선택한 제품을 최소 1개 이상 구매하셔야 합니다.");
                        if (milkCheckbox.checked) {
                            document.getElementById("milk").value = 1;
                        }
                        if (mandooCheckbox.checked) {
                            document.getElementById("mandoo").value = 1;
                        }
                        if (noshimCheckbox.checked) {
                            document.getElementById("noshim").value = 1;
                        }
                } else if (hasExceededQuantity) {
                    event.preventDefault();
                    alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
                    if (milkCheckbox.checked) {
                        document.getElementById("milk").value = 10;
                    }
                    if (mandooCheckbox.checked) {
                        document.getElementById("mandoo").value = 10;
                    }
                    if (noshimCheckbox.checked) {
                        document.getElementById("noshim").value = 10;
                    }
                }



    });

    // 날짜 유효성 검사 함수
    function isValidDateInput(month, day, year) {
        var maxDaysInMonth = new Date(year, month, 0).getDate();
        return month >= 1 && month <= 12 && day >= 1 && day <= maxDaysInMonth;
    }


});


