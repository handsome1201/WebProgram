<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="test03.css">
    <title>주문 정보</title>
</head>

<body>
    <table class="table table-bordered">
        <tr>
            <td><strong>이름</strong></td>
            <td><strong>등급</strong></td>
            <td><strong>날짜</strong></td>
            <td><strong>제품 구매 금액</strong></td>
            <td><strong>최종 결제 금액</strong></td>
        </tr>

        <?php
        // data.txt 파일에서 주문 정보를 읽어오는 함수
        function readOrderData()
        {
            $orders = [];
            $file = fopen('data.txt', 'r');

            if ($file) {
                while (($line = fgets($file)) !== false) {
                    $orders[] = explode('|', trim($line));
                }
                fclose($file);
            }

            return $orders;
        }

        // 주문 금액을 계산하는 함수
        function calculateOrderAmount($milkQuantity, $mandooQuantity, $noshimQuantity)
        {
            $milkPrice = 4500;
            $mandooPrice = 6900;
            $noshimPrice = 3500;
            return $milkPrice * $milkQuantity + $mandooPrice * $mandooQuantity + $noshimPrice * $noshimQuantity;
        }

        // 최종 결제 금액을 계산하는 함수
        function calculateFinalPayment($orderAmount, $discountRate, $deliveryThreshold, $deliveryFee)
        {
            $discountedAmount = $orderAmount * (1 - $discountRate);
            if ($discountedAmount >= $deliveryThreshold) {
                return $discountedAmount; // 배송비 면제
            } else {
                return $discountedAmount + $deliveryFee; // 배송비 추가
            }
        }

        // 주문 데이터 읽기
        $orders = readOrderData();

        // 주문 정보 출력
        foreach ($orders as $order) {
            $name = $order[0];
            $grade = $order[1];
            $date = $order[2];
            $milkQuantity = intval($order[3]);
            $mandooQuantity = intval($order[4]);
            $noshimQuantity = intval($order[5]);

            // 주문 금액 계산
            $orderAmount = calculateOrderAmount($milkQuantity, $mandooQuantity, $noshimQuantity);

            // 할인율 및 배송비 설정
            $discountRate = 0;
            if ($grade == 'vip') {
                $discountRate = 0.1;
            } elseif ($grade == 'gold') {
                $discountRate = 0.05;
            }

            $deliveryThreshold = 10000; // 1만원 이상 무료 배송
            $deliveryFee = 2000; // 배송비 2000원

            // 최종 결제 금액 계산
            $finalPayment = calculateFinalPayment($orderAmount, $discountRate, $deliveryThreshold, $deliveryFee);

            echo "<tr><td>$name</td><td>$grade</td><td>$date</td><td>$orderAmount</td><td>$finalPayment</td></tr>";
        }
        ?>
    </table>
</body>

</html>
