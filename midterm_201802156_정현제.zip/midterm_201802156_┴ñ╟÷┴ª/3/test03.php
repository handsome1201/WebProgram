<?php
// 사용자 입력 데이터에서 특정 문자를 HTML 엔티티로 변환
$name = htmlspecialchars($_POST['name']);
$grade = htmlspecialchars($_POST['select']);
$month = htmlspecialchars($_POST['month']);
$day = htmlspecialchars($_POST['day']);
$milkQuantity = ($_POST['milk'] > 0) ? $_POST['milk'] : '없음';
$mandooQuantity = ($_POST['mandoo'] > 0) ? $_POST['mandoo'] : '없음';
$noshimQuantity = ($_POST['noshim'] > 0) ? $_POST['noshim'] : '없음';

// 불필요한 문자(공백 등)를 제거
$name = trim($name);
$grade = trim($grade);
$month = trim($month);
$day = trim($day);

// 백슬래시를 제거
$name = stripslashes($name);
$grade = stripslashes($grade);
$month = stripslashes($month);
$day = stripslashes($day);

// data.txt 파일 열기 (없으면 생성)
$file = fopen('data.txt', 'a');

if ($file) {
    // 날짜 형식 만들기 (YYYY-MM-DD)
    $date = date('Y-m-d', strtotime($month . '-' . $day));

    // 데이터 문자열 만들기
    $data = "$name|$grade|$date|$milkQuantity|$mandooQuantity|$noshimQuantity";

    // 데이터 저장
    fwrite($file, $data . PHP_EOL);

    // 파일 닫기
    fclose($file);

    // 저장 성공 메시지 출력
    echo "저장되었습니다";
} else {
    // 파일 열기 실패 메시지 출력
    echo "파일을 열 수 없습니다";
}
?>
