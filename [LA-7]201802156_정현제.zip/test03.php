<?php

$name = htmlspecialchars($_POST['name']);
$grade = htmlspecialchars($_POST['select']);
$month = htmlspecialchars($_POST['month']);
$day = htmlspecialchars($_POST['day']);
$milkQuantity = (isset($_POST['milk']) && $_POST['milk'] > 0) ? (int)$_POST['milk'] : 0;
$mandooQuantity = (isset($_POST['mandoo']) && $_POST['mandoo'] > 0) ? (int)$_POST['mandoo'] : 0;
$noshimQuantity = (isset($_POST['noshim']) && $_POST['noshim'] > 0) ? (int)$_POST['noshim'] : 0;

// 불필요한 문자(공백 등)를 제거
$name = trim($name);
$grade = trim($grade);
$month = trim($month);
$day = trim($day);

// 백슬래시를 제거
$name = stripslashes($name);
$grade = stripslashes($grade);
$month = stripslashes($month);
$day = stripslashes($day);

// 날짜 형식 만들기 (YYYY-MM-DD)
$date = date('Y-m-d', strtotime('2023-' . $month . '-' . $day));

// 데이터 배열 생성
$data = [
    'name' => $name,
    'grade' => $grade,
    'date' => $date,
    'milkQuantity' => $milkQuantity,
    'mandooQuantity' => $mandooQuantity,
    'noshimQuantity' => $noshimQuantity
];

// 데이터를 JSON 형식으로 변환
$jsonData = json_encode($data, JSON_UNESCAPED_UNICODE);

// data.txt 파일에 JSON 데이터 추가
$file = fopen('data.txt', 'a');

if ($file) {
    // JSON 데이터를 파일에 저장하고 줄 바꿈 추가
    fwrite($file, $jsonData . PHP_EOL);

    // 파일 닫기
    fclose($file);

    // 저장 성공 메시지 출력
    echo "저장되었습니다";
} else {
    // 파일 열기 실패 메시지 출력
    echo "파일을 열 수 없습니다";
}
?>