function updateQuantityField(product, quantity) {
    document.getElementById(product).value = quantity;
}

function validateForm() {
    var name = document.getElementById("name").value;
    var monthInput = parseInt(document.getElementsByName("month").value);  // 사용자 입력값을 정수로 변환
    var dayInput = parseInt(document.getElementsByName("day").value);  // 사용자 입력값을 정수로 변환
    var milkQuantity = parseInt(document.getElementById("milk").value);
    var mandooQuantity = parseInt(document.getElementById("mandoo").value);
    var noshimQuantity = parseInt(document.getElementById("noshim").value);
    var gradeSelected = document.querySelector('input[name="select"]:checked');
    var milkChecked = document.getElementsByName("milkcheck")[0].checked;
    var mandooChecked = document.getElementsByName("mandoocheck")[0].checked;
    var noshimChecked = document.getElementsByName("noshimocheck")[0].checked;

    // ① 유효성 검사: 이름에 문자가 입력되었는지 확인
    if (!/^[A-Za-z가-힣]+$/.test(name)) {
        alert("이름에 문자를 입력해 주세요.");
        return false;
    }

    // ② 유효성 검사: 등급이 선택되었는지 확인
    if (gradeSelected === null) {
        alert("고객의 등급을 선택해 주세요.");
        return false;
    }

    // ③ (a) 월, 일에 숫자가 입력되었는지 확인
    if (isNaN(monthQuantity) || isNaN(dayQuantity)) {
        alert("날짜에 숫자를 입력해 주세요.");
        return false;
    }

    var currentDate = new Date(2023, monthInput, dayInput);
    if (currentDate.getMonth() !== monthInput || currentDate.getDate() !== dayInput) {
        alert("유효한 날짜를 입력해 주세요.");
        return false;
    }

    // ④ 유효성 검사: 최소 한 개의 제품이 선택되었는지 확인
    if (!milkChecked && !mandooChecked && !noshimChecked) {
        alert("최소 한 개의 제품을 선택하셔야 합니다.");
        return false;
    }
        if (milkChecked && mandooChecked && milkQuantity === 0 && mandooQuantity > 10) {
        updateQuantityField("milk", 1);
        updateQuantityField("mandoo", 10);
        alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
        return false;
    }
    if (milkChecked && mandooChecked && milkQuantity >10 && mandooQuantity === 0) {
        updateQuantityField("milk", 10);
        updateQuantityField("mandoo", 1);
        alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
        return false;
    }
    if (milkChecked && noshimChecked && milkQuantity === 0 && noshimQuantity > 10) {
        updateQuantityField("milk", 1);
        updateQuantityField("noshim", 10);
        alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
        return false;
    }
    if (milkChecked && noshimChecked && milkQuantity >10 && noshimQuantity === 0) {
        updateQuantityField("milk", 10);
        updateQuantityField("noshim", 1);
        alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
        return false;
    }
        if (noshimChecked && mandooChecked && noshimQuantity === 0 && mandooQuantity > 10) {
        updateQuantityField("noshim", 1);
        updateQuantityField("mandoo", 10);
        alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
        return false;
    }
    if (noshimChecked && mandooChecked && noshimQuantity >10 && mandooQuantity === 0) {
        updateQuantityField("noshim", 10);
        updateQuantityField("mandoo", 1);
        alert("선택한 제품을 최소 1개 이상 최대 10개까지만 구매 가능합니다.");
        return false;
    }
    // ⑤ (a) 수량이 0인 제품이 있는 경우 1로 변경
    if (milkChecked && milkQuantity === 0) {
        updateQuantityField("milk", 1);
        alert("선택한 제품을 최소 1개 이상 구매하셔야 합니다.");
        return false;
    }
    if (mandooChecked && mandooQuantity === 0) {
        updateQuantityField("mandoo", 1);
        alert("선택한 제품을 최소 1개 이상 구매하셔야 합니다.");
        return false;
    }
    if (noshimChecked && noshimQuantity === 0) {
        updateQuantityField("noshim", 1);
        alert("선택한 제품을 최소 1개 이상 구매하셔야 합니다.");
        return false;
    }
    if (milkChecked && milkQuantity > 10) {
        updateQuantityField("milk", 10);
        alert("선택한 제품을 최대 10개까지만 구매 가능합니다.");
        return false;
    }
    if (mandooChecked && mandooQuantity > 10) {
        updateQuantityField("mandoo", 10);
        alert("선택한 제품을 최대 10개까지만 구매 가능합니다.");
        return false;
    }
    if (noshimChecked && noshimQuantity > 10) {
        updateQuantityField("noshim", 10);
        alert("선택한 제품을 최대 10개까지만 구매 가능합니다.");
        return false;
    }

    return true;
}

// form 요소에 onsubmit 이벤트를 추가하여 validateForm 함수를 실행
document.getElementsByTagName("form")[0].onsubmit = function() {
    return validateForm();
};



