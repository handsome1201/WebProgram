<?php
// 제품 가격 정보 (우유, 만두, 라면)
$productPrices = [
    'milk' => 4500,
    'mandoo' => 6900,
    'noshim' => 3500
];

// 할인율 정보
$discounts = [
    'vip' => 0.1,
    'gold' => 0.05,
    'ace' => 0
];

// 배송비
$shippingCost = 2000;

// 제품 구매 금액 계산 함수
function calculateTotalPrice($milkQuantity, $mandooQuantity, $noshimQuantity, $productPrices) {
    return ($milkQuantity * $productPrices['milk']) +
           ($mandooQuantity * $productPrices['mandoo']) +
           ($noshimQuantity * $productPrices['noshim']);
}

// 최종 결제 금액 계산 함수
function calculateFinalPrice($totalPrice, $grade, $discounts, $shippingCost) {
    $discountRate = isset($discounts[$grade]) ? $discounts[$grade] : 0;
    $discountedPrice = $totalPrice - ($totalPrice * $discountRate);
    $finalPrice = ($discountedPrice >= 10000) ? $discountedPrice : ($discountedPrice + $shippingCost);
    return $finalPrice;
}

// data.txt 파일에서 주문 정보 읽어오는 함수
function searchOrderInfo($name, $date) {
    $orders = [];

    // 파일을 읽어와서 배열에 저장
    $file = fopen('data.txt', 'r');
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $order = json_decode($line, true);
            // 이름과 날짜로 필터링
        if (
            isset($order['name'], $order['date'], $order['milkQuantity'], $order['mandooQuantity'], $order['noshimQuantity'], $order['grade']) &&
            ($name === '' || $order['name'] === $name) &&
            ($date === '' || strtotime($order['date']) >= strtotime($date))
        ) {
            // 이하 코드는 그대로 둡니다.
            $order['totalPrice'] = calculateTotalPrice($order['milkQuantity'], $order['mandooQuantity'], $order['noshimQuantity'], $GLOBALS['productPrices']);
            $order['finalPrice'] = calculateFinalPrice($order['totalPrice'], $order['grade'], $GLOBALS['discounts'], $GLOBALS['shippingCost']);
            $orders[] = $order;
        }
    }
        fclose($file);
    }

    return $orders;
}

// 사용자 입력 데이터에서 특수 문자 처리
$name = htmlspecialchars($_POST['name']);
$date = htmlspecialchars($_POST['date']);

// 검색 결과 받아오기ㄴ
$orders = searchOrderInfo($name, $date);

// 결과 출력
echo '<table border="1">';
echo '<tr><th>이름</th><th>등급</th><th>날짜</th><th>제품 구매 금액</th><th>최종 결제 금액</th></tr>';
foreach ($orders as $order) {
    echo '<tr>';
    echo '<td>' . $order['name'] . '</td>';
    echo '<td>' . $order['grade'] . '</td>';
    echo '<td>' . $order['date'] . '</td>';
    echo '<td>' . $order['totalPrice'] . '원</td>';
    echo '<td>' . $order['finalPrice'] . '원</td>';
    echo '</tr>';
}
echo '</table>';
?>
