<?php
session_start();
if ($_SESSION["student"] == null) {
    $_SESSION["student"] = array();
}
?>

<!DOCTYPE html>
<html lang="ko">
<body>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $grade = $_POST["grade"];
    $arr = array($name, $grade);
    array_push($_SESSION["student"], $arr);
    echo "세선에 저장되었습니다.";

}
?>
</body>