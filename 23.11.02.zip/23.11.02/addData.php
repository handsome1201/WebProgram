<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $name = $height = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = test_input($_POST["name"]);
    $height = test_input($_POST["height"]);
    }

    function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
    }
    ?>

    <?php
    $myfile = fopen("data.txt", "a");
    $data = $_POST["name"] . "|" . $_POST["height"] . "\n";
    fwrite($myfile, $data);
    fclose($myfile);
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    <p>데이타 저장하기<p>
    이름 : <input type="text" name="name"><br>
    키 : <input type="number" name="height"><br>
    <input type="submit">
    </form>

    



    
</body>
</html>