<?php
session_start();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="phstyle.css">   
    <style>
        table, th, td {
            border : 1px solid black;
            border-collapse : collapse;
        }
    </style>
</head>
<body>
<?php

$name = isset($_POST["name"]) ? $_POST["name"] : null;
$grade = isset($_POST["grade"]) ? $_POST["grade"] : null;

$result = '<table>';
$result .= "<tr><th>학생 이름</th><th>학년</th></tr>";

$size = count($_SESSION["student"]);

for ($i = 0; $i < $size; $i++) {
    $stu = isset($_SESSION["student"][$i]) ? $_SESSION["student"][$i] : null;

    $getName = isset($_SESSION["student"][$i][0]) ? $_SESSION["student"][$i][0] : null;
    $getGrade = isset($_SESSION["student"][$i][1]) ? $_SESSION["student"][$i][1] : null;

    if ((empty($name) || strpos($getName, $name) !== false) &&
        (empty($grade) || $getGrade == $grade)) {
        $getGradeText = "";
        switch($getGrade) {
            case 'first':
                $getGradeText = "1학년";
                break;
            case 'second':
                $getGradeText = "2학년";
                break;
            case 'third':
                $getGradeText = "3학년";
                break;
            case 'forth':
                $getGradeText = "4학년";
                break;
        }
        $result .= "<tr><td>$getName</td><td>$getGradeText</td></tr>";
    }
}

$result .= "</table>";

echo $result;
?>
</body>
</html>
